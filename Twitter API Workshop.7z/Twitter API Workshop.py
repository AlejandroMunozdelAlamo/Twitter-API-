#!/usr/bin/env python
# -*- coding: cp850 -*

import tweepy
import re
import numpy as np
import matplotlib.pyplot as plt
import encodings

encodings.aliases.aliases['utf-8'] = 'cp65001'

user_id = 'u\'id: *?,'
user_name ='u\'name: *?,'
user_screen_name ='u\'screen_name: *?,'
description ='u\'description: *?,'
user_status_text ='u\'text: *?,'
follow_req ='u\'follow_request_sent: *?,'
friends_count ='u\'friends_count: *?,'
followers_count ='u\'followers_count: *?,'
numbering = "\t -> "

# Funcion que nos identifica y nos permite acceder a la API

def login():

	consumer_key='2EtiJK3cvO2fcS1S2V7eynebC'
	consumer_secret='VSlhvNlGaweuT1s2tgVCrpCvdovxk83hlYFScxW7ooYvMPCOKn'
	access_token='2324185926-sfZHWUetP1oy4ryrE0V2k7G7xBpkcPLf9Q8e1gm'
	access_token_secret='ASaiJnIfIGMgiTFiQoeTRAnJWb9MIzG0uZ7P0iOjzyOts'

	auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
	auth.set_access_token(access_token, access_token_secret)

	api = tweepy.API(auth)
	return api

main = login()

# Funcion que muestra los datos del usuario
def mostrar_datos_usuario(user):
	print "\tUser_ID : " + str(user.id)
	print "\tUser_name : " + user.name.encode('utf-8')
	print "\tUser_screen_name : " + user.screen_name.encode('utf-8')
	print "\tUser_description : " + user.description.encode('utf-8')
	print "\tUser_tweets_count : " + str(user.statuses_count)
	print "\tUser_friends : " + str(user.friends_count)
	print "\tUser_followers : " + str(user.followers_count)
	if user.geo_enabled == True:
		print "\tUser_location : " + str(user.location)
	print "\n"

# Funcion que muestra los datos de un tweet (estado)
def mostrar_datos(estado):
	print "\tAuthor : " + str(estado.author.screen_name) #Obtener nombre original
	text = "u" + estado.text
	print "\tStatus_description : " + text.encode('utf-8')
	print "\tRetweets_count : " + str(estado.retweet_count)
	print "\tFavorite_count : " + str(estado.favorite_count)
	print "\t-------------------------------------------------------------------------"
	print "\n"

# Funcion que muestra los datos del usuario actual
def mostrar_usuario():
	mostrar_datos_usuario(main.me())

# Funcion que muestra el timeline del usuario actual
def mostrar_timeline():
	user = main.me()
	timeline = main.user_timeline(user.id)
	for i in timeline:
		mostrar_datos(i)

# Funcion que muestra el nombre de los friends del usuario actual
def mostrar_friends():
	user = main.me()
	friends = main.friends_ids(user.id)
	print("\tFriends List :\n")
	for f in friends:
		name = main.get_user(f).screen_name
		print numbering.encode('utf-8') + name.encode('utf-8')
	print "\n"

# Funcion que muestra el nombre de los followers del usuario actual
def mostrar_followers():
	user = main.me()
	followers = main.followers_ids(user.id)
	print("\tFollowers List :\n")
	for f in followers:
		name = main.get_user(f).screen_name
		print numbering.encode('utf-8') + name.encode('utf-8')
	print "\n"

# Funcion que mustra los seguidores de los N primeros seguidores del usuario actual
def grafica():
	user = main.me()
	followers = main.followers(user.id)
	x = list()
	y = list()
	print " Introduzca el numero de seguidores que desee mostrar en la gráfica"
	N = input()
	for usuario in followers[0:N]:
		x += [usuario.screen_name]			# nombres de los seguidores
		y += [usuario.followers_count]		# numero de seguidores

	ind = np.arange(len(x))    	# the x locations for the groups
	width = 0.5   		# the width of the bars: can also be len(x) sequence

	p2 = plt.bar(ind, y, width, color='y')

	plt.ylabel('Numero de seguidores')
	plt.title('Numero de seguidores / nombres')
	plt.xticks(ind + width/2., x)
	plt.yticks(np.arange(0, max(y), 30))

	plt.show()

# funcion que mostrara los ultimos tweets de una persona y dara a alegir para que el usuario decida que tweet comprobar el mumero de favoritos y retwets
def grafica2():
	user = main.me()
	timeline = main.user_timeline(user.id)
	cont = 0
	for i in timeline:
		print "  " + str(cont) + ".-" + i.text.encode('utf-8')
		cont+=1

 	print "\tIntroduzca el numero del tweet que quieras comprobar"
 	i = timeline[input()]

 	x = ["Retweets" , "Favoritos"]
 	y = [ i.retweet_count , i.favorite_count]

 	ind = np.arange(len(x))     # the x locations for the groups
 	width = 0.5     # the width of the bars: can also be len(x) sequence

 	p2 = plt.bar(ind, y, width, color='y')

 	plt.ylabel('Numero de seguidores')
 	plt.title('Retweets / Favoritos')
 	plt.xticks(ind + width/2., x)
 	plt.yticks(np.arange(0, max(y)+1, (max(y)+1)/5.))

 	plt.show()

# Función del Menú Principal
def menu():

	menu = {}
	menu[''] = "\t Menu Principal: \n"
	menu['\t1'] = " - Mostrar el usuario actual"
	menu['\t2'] = " - Mostrar el timeline del usuario actual"
	menu['\t3'] = " - Mostrar los usuarios que sigues y los que te siguen"
	menu['\t4'] = " - Mostrar gráfica de followers de los N followers mas recientes\n\t     del usuario actual"
	menu['\t5'] = " - Mostrar gráfica comparativa de los retweets y\n\t     los favoritos de un tweet del timeline del usuario"
	menu['\t6'] = " - Salir de la aplicacion\n"

	while True:
		options=menu.keys()
		options.sort()
		for entry in options:
			print entry, menu[entry]

		opcionMenu=raw_input(" Por favor, seleccione una opción\n Opcion seleccionada: ")

		if opcionMenu == "1":
			print ""
			mostrar_usuario()

		elif opcionMenu == "2":
			print ""
			mostrar_timeline()

		elif opcionMenu == "3":
			print ""
			mostrar_friends()
			print ""
			mostrar_followers()
			
		elif opcionMenu == "4":
			print ""
			grafica()

		elif opcionMenu == "5":
			print ""
			grafica2()

		elif opcionMenu == "6":
			print "\n Muchas gracias. Esperamos que la aplicación le haya sido de utilidad\n"
			break

print "\n Twitter Api Workshop\n Aplicación realizada por Abel Castilla Rodríguez y Alejandro Muñoz del Álamo\n"
menu()